let fetch = require('node-fetch')
let handler = async (m, { conn, usedPrefix, command }) => {
m.reply(wait)
  await conn.sendButtonImg(m.chat, `https://api.zacros.my.id/randomimg/husbu`, 'mas saya nih', 'Lui gmntng', 'Next', `.husbu`, m)

}
handler.help = ['husbu']
handler.tags = ['random']
handler.command = /^(husbu)$/i

module.exports = handler

let koncol = global.wm